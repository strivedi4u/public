import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
function PaypalMessage(props) {
    const navigate = useNavigate();
    // const [phone, setPhone] = useState();
    // const [company, setCompany] = useState();
    // const [comment, setComment] = useState();
    // const [firstName, setFirstName] = useState();
    // const [lastName, setLastName] = useState();
    // const [email, setEmail] = useState();
    // const [address, setAddress] = useState();
    // const [country, setCountry] = useState();
    // const [state, setState] = useState();
    // const [city, setCity] = useState();
    // const [postalCode, setPostalCode] = useState();
    // const [checkbox, setCheckbox] = useState(0);

    const API = props.API;
    console.log(API);
    useEffect(() => {
        const getPayPal = async () => {
            if (localStorage.getItem("checkbox") == 1) {
                try {
                    let response = await axios.post(API, {
                        money: props.money,
                        token: props.token,
                        paymentId: props.paymentId,
                        payerId: props.payerId,
                        phone: localStorage.getItem("phone"),
                        company: localStorage.getItem("company"),
                        comment: localStorage.getItem("comment"),
                    });
                    console.log("CHECKBOX");
                    console.log(response);
                    if(response.status === 200){
                        navigate("/payment/" + response.data.transactionId);
                    }
                } catch (error) {
                    console.log("Error in CheckBOX");
                    navigate("/");
                }
            } else {
                try {
                    let response = await axios.post(API, {
                        money: props.money,
                        token: props.token,
                        paymentId: props.paymentId,
                        payerId: props.payerId,
                        phone: localStorage.getItem("phone"),
                        company: localStorage.getItem("company"),
                        comment: localStorage.getItem("comment"),
                        firstName: localStorage.getItem("firstName"),
                        lastName: localStorage.getItem("lastName"),
                        email: localStorage.getItem("email"),
                        address: localStorage.getItem("address"),
                        country: localStorage.getItem("country"),
                        state: localStorage.getItem("state"),
                        city: localStorage.getItem("city"),
                        postalCode: localStorage.getItem("postalCode"),
                    });
                    console.log("Without Checkbox");
                    if(response.status === 200){
                        navigate("/payment/" + response.data.transactionId);
                    }
                } catch (error) {
                    console.log("Error without Checkbox");
                    navigate("/");
                }

            }
        }
        getPayPal();
    }, []);



    return (
        <div className="subscribe"><center>
            <h1>Your Transcation is running! <br></br>Please don't refresh & close the tab.</h1></center>
        </div>
    );
}

export default PaypalMessage;
