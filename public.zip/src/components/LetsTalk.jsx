import React, { useState } from 'react';
import swal from 'sweetalert';
import axios from 'axios';
import "../css/LetsTalk.css";
function LetsTalk(props) {
    const [btnText, setBtnText] = useState(<i className="fa fa-paper-plane"></i>);
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    const [phone, setPhone] = useState();
    const [message, setMessage] = useState();

    const [whatsapp, setWhatsapp] = useState(0);
    const [iMessage, setIMessage] = useState(0);
    const [faceTime, setFaceTime] = useState(0);
    const [Email, setemail] = useState(0);


    const API = props.URL + 'api/email/';

    const sendQuery = async (e) => {
        e.preventDefault();
        setBtnText("Sending......");
        var status = "User want to connect these communication channel ";
        if (whatsapp) {
            status += "WhatsApp, ";
        }
        if (iMessage) {
            status += "iMessage, ";
        }
        if (faceTime) {
            status += "FaceTime, ";
        }
        if (Email) {
            status += "Email, ";
        }
        try {
            var response = await axios.post(API, {
                to: "er.shivangtrivedi@gmail.com",
                subject: "Query Message Sended by the User",
                message: {
                    name: name,
                    email: email,
                    phone: phone,
                    text: message + status,
                },
                sender: "user"
            },
            );
            if (response.status === 200) {
                swal("Good job!", "Message have been successfully Send", "success");
                setName("");
                setEmail("");
                setPhone("");
                setMessage("");
            }
            else {
                swal("Unfortunatilly!", "Message have not been Send", "error");
            }
        }
        catch (error) {
            swal("Unfortunatilly!", "Internal Server Error", "error");
        }
        setBtnText(<i className="fa fa-paper-plane"></i>);

    };



    return (
        <div className="subscribe">
            <div className="container">
                <div className="row">
                    <div className="col-lg-8">
                        <div className="section-heading">
                            <h2>Let's Talk, Send us an inquiry</h2>
                            <span>Contact us to know about any French or English Bull Dog's puppies</span>
                        </div>
                        <form onSubmit={sendQuery} method='POST' id="subscribe">
                            <div className="row">
                                <div className="col-lg-3">
                                    <fieldset>
                                        <input value={name} onChange={e => setName(e.target.value)} type="text" id="name" placeholder="Your Name" required />
                                    </fieldset>
                                </div>
                                <div className="col-lg-3">
                                    <fieldset>
                                        <input value={email} onChange={e => setEmail(e.target.value)} type="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Email Address" required />
                                    </fieldset>
                                </div>

                                <div className="col-lg-3">
                                    <fieldset>
                                        <input value={phone} onChange={e => setPhone(e.target.value)} type="number" id="phone" pattern="" placeholder="Phone Number" required />
                                    </fieldset>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-lg-9">
                                    <center>
                                        <label>
                                            <input onChange={e => setWhatsapp(e.target.value)} type="checkbox" id="Whatsapp" pattern="" placeholder="" value="1" />
                                            <span value="">Whatsapp</span></label>
                                        <label>
                                            <input onChange={e => setIMessage(e.target.value)} type="checkbox" id="iMessage" pattern="" placeholder="" value="1" />
                                            <span value="">iMessage</span></label>
                                        <label>
                                            <input onChange={e => setFaceTime(e.target.value)} type="checkbox" id="FaceTime" pattern="" placeholder="" value="1" />
                                            <span value="">FaceTime</span></label>
                                        <label>
                                            <input onChange={e => setemail(e.target.value)} type="checkbox" id="semail" pattern="" placeholder="" value="1" />
                                            <span value="">Email</span></label>
                                        <p>[Please mark your preferred communication channel in which we can reach out to you.]!!!</p>
                                    </center>
                                </div>

                            </div>
                            <div className="row">
                                <div className="col-lg-9">
                                    <fieldset>
                                        <textarea value={message} onChange={e => setMessage(e.target.value)} type="text" id="msg" pattern="" placeholder="Message" required></textarea>
                                    </fieldset>
                                </div>
                            </div>
                            <div className="row">

                                <div className="col-lg-9">
                                    <center>
                                        <fieldset>
                                            <button type="submit" id="form-submit" className="main-dark-button">{btnText}</button>
                                        </fieldset>
                                    </center>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div className="col-lg-4">
                        <div className="row">
                            <div className="col-6">
                                <ul>
                                    <li>Store Location:<br></br><span>Jason Montana, Dubai, United Arab Emirates</span></li>
                                    <li>Phone:<br></br><span>010-020-0340</span></li>
                                    <li>Office Location:<br></br><span>United Arab Emirates</span></li>
                                </ul>
                            </div>
                            <div className="col-6">
                                <ul>
                                    <li>Work Hours:<br></br><span>07:30 AM - 9:30 PM Daily</span></li>
                                    <li>Email:<br></br><span>info@company.com</span></li>
                                    <li>Social Media:<br></br><span><a href="/">Facebook</a>, <a href="/">Instagram</a>, <a href="/">Behance</a>, <a href="/">Linkedin</a></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default LetsTalk;
