import React from "react";
import './App.css';
import swal from "sweetalert";
import { BrowserRouter, Routes, Route } from "react-router-dom";

/////////////////////Admin///////////////////////
import Dashboard from "./pages/admin/Dashboard";
import AddPuppie from "./pages/admin/AddPuppie";
import AdminAvailable from "./pages/admin/AdminAvailable";
import AdminUnavailable from "./pages/admin/AdminUnavailable";
import Payment from "./pages/admin/Payment";
import Login from "./pages/admin/Login";
/////////////////////Welcome///////////////////////
import Home from "./pages/welcome/Home";
import AvailablePuppie from "./pages/welcome/AvailablePuppie";
import PageNotFound from "./pages/welcome/404";
import PaypalSuccess from "./pages/welcome/PaypalSuccess";
import PaypalCancel from "./pages/welcome/PaypalCancel";
import PaymentSearch from "./pages/welcome/PaymentSearch";
import About from "./pages/welcome/About";
import Checkout from "./pages/welcome/Checkout";
import Search from "./pages/welcome/Search";
import FrenchPuppie from "./pages/welcome/FrenchPuppie";
import EnglishPuppie from "./pages/welcome/EnglishPuppie";
import BoyPuppie from "./pages/welcome/BoyPuppie";
import GirlPuppie from "./pages/welcome/GirlPuppie";
import ContactUs from "./pages/welcome/ContactUs";

/////////////////////Components///////////////////////



// Set timeout for 1 hour (in milliseconds)
const timeout = 60 * 60 * 1000;

// Set timer to clear session storage after timeout
setTimeout(() => {
  var loggedIn = sessionStorage.getItem("auth-token");
  if (loggedIn) {
    swal("Oh No!", "Session Timeout !", "error");
  }
  sessionStorage.clear();
}, timeout);

const URL = "http://localhost:5000/";

function App() {
  return (
    <BrowserRouter>
      <Routes >
        <Route exact path="/" element={<Home URL={URL} />} />
        <Route exact path="/available" element={<AvailablePuppie URL={URL} />} />
        <Route path="about/:name" element={<About URL={URL} />} />
        <Route exact path="/checkout" element={<Checkout URL={URL} />} />
        <Route exact path="/success" element={<PaypalSuccess URL={URL} />} />
        <Route exact path="/cancel" element={<PaypalCancel />} />
        <Route exact path="payment/:transcationId" element={<PaymentSearch URL={URL} />} />
        <Route exact path="/frenchPuppies" element={<FrenchPuppie URL={URL} />} />
        <Route exact path="/englishPuppies" element={<EnglishPuppie URL={URL} />} />
        <Route exact path="/boyPuppies" element={<BoyPuppie URL={URL} />} />
        <Route exact path="/girlPuppies" element={<GirlPuppie URL={URL} />} />
        <Route exact path="/contact" element={<ContactUs URL={URL} />} />
        <Route exact path="*" element={<PageNotFound />} />

        <Route exact path="/dashboard" element={<Dashboard URL={URL} />} />
        <Route exact path="/addPuppies" element={<AddPuppie URL={URL} />} />
        <Route exact path="/login" element={<Login URL={URL} />} />
        <Route exact path="/availablePuppies" element={<AdminAvailable URL={URL} />} />
        <Route exact path="/unavailablePuppies" element={<AdminUnavailable URL={URL} />} />
        <Route exact path="/payments" element={<Payment URL={URL} />} />
        <Route exact path="/search" element={<Search />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
