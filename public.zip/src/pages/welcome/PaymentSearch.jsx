import React from 'react';
import { useParams } from "react-router-dom";
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import PageHeader from '../../components/PageHeader';
import PrintPayment from '../../components/PrintPayment';
function PaymentSearch(props) {
    let { transcationId } = useParams();
    const URL = props.URL;
    return (
        <>
            <Navbar />
            <PageHeader title={["Fall in love with our",
                "adorable bulldog's puppies",
                "They are intelligent",
                "They are easy to train",
                "They love to play",
                "They are looking for",
                "Loving homes like yours!"]}
                des={"We have a variety of adorable bulldog puppies that are looking for loving and caring homes. Here are some details about the puppies that we currently have available:"}
            />
            
            <PrintPayment URL={URL} TranscationId={transcationId} />
            <Footer />
        </>
    );
}

export default PaymentSearch;
