import React from 'react';
import PaypalMessage from '../../components/PaypalMessage';
function PaypalSuccess(props) {
    const URL = props.URL;
    const queryParams = new URLSearchParams(window.location.search);

    const money = queryParams.get('money');
    const paymentId = queryParams.get('paymentId');
    const token = queryParams.get('token');
    const payerId = queryParams.get('PayerID');

    const API = URL + 'api/paypal/success/';

    return (
        <>
            <PaypalMessage URL={URL} API={API} money={money} paymentId={paymentId} token={token} payerId={payerId} />
        </>
    );
}

export default PaypalSuccess;
